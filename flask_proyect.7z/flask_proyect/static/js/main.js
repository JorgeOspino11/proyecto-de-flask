document.addEventListener("DOMContentLoaded", () => {
  console.log("✅ Proyecto Flask cargado correctamente");

  if (window.location.pathname === "/") {
    setTimeout(() => {
      alert("Bienvenido a la página principal 🚀");
    }, 1000);
  }
});
